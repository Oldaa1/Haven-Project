extends Button

@export var asteroid_scene: PackedScene
@export var spawn_at = Vector2(0, 0)


func _pressed():
	var asteroid = asteroid_scene.instantiate()
	asteroid.position = Vector2(0, 0)
	get_tree().current_scene.add_child(asteroid)
