extends CanvasLayer

var score = 0
var panel = PanelContainer.new()
var number = Label.new()


func _ready():
	add_to_group("counter")

	var style = StyleBoxFlat.new()
	style.bg_color = Color(0.07, 0.07, 0.13, 0.85)
	style.border_color = Color(1.0, 0.6, 0.2)
	style.set_border_width_all(3)
	style.set_corner_radius_all(12)
	style.shadow_size = 8
	style.shadow_color = Color(0, 0, 0, 0.5)
	style.content_margin_left = 20
	style.content_margin_right = 20
	style.content_margin_top = 10
	style.content_margin_bottom = 10
	panel.add_theme_stylebox_override("panel", style)

	var box = VBoxContainer.new()
	box.add_theme_constant_override("separation", 0)

	var title = Label.new()
	title.text = "ASTEROIDS POPPED"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 14)
	title.add_theme_color_override("font_color", Color(1.0, 0.6, 0.2))

	number.text = "000"
	number.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	number.add_theme_font_size_override("font_size", 48)
	number.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	number.add_theme_constant_override("outline_size", 6)

	box.add_child(title)
	box.add_child(number)
	panel.add_child(box)
	add_child(panel)

	panel.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
	panel.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	panel.grow_vertical = Control.GROW_DIRECTION_BEGIN
	panel.offset_right = -20
	panel.offset_bottom = -20


func add_point():
	score += 1
	number.text = "%03d" % score

	panel.pivot_offset = panel.size / 2
	number.modulate = Color(1.0, 0.85, 0.3)
	var tween = create_tween()
	tween.set_parallel(true)
	tween.tween_property(panel, "scale", Vector2.ONE, 0.25).from(Vector2(1.2, 1.2)).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tween.tween_property(number, "modulate", Color.WHITE, 0.25)
