extends Area2D

@export var speed: float = 700.0

func _process(delta: float) -> void:
	global_position += Vector2.RIGHT.rotated(global_rotation) * speed * delta
