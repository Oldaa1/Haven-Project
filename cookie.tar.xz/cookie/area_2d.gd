extends Area2D

@export var asteroid_scene: PackedScene
@export var start_delay = 1.0
@export var min_delay = 0.25
@export var speed_up = 0.02
@export var max_asteroids = 15
@export var active = true

@onready var box = $CollisionShape2D

var delay = 0.0


func _ready():
	randomize()
	collision_layer = 0
	collision_mask = 0
	if asteroid_scene == null:
		push_error(name + "res://asteroid.tscn")
		return
	delay = start_delay
	run()


func run():
	while true:
		await get_tree().create_timer(delay).timeout
		if active and get_tree().get_nodes_in_group("asteroid").size() < max_asteroids:
			spawn()
			delay = max(min_delay, delay - speed_up)


func spawn():
	var asteroid = asteroid_scene.instantiate()
	get_tree().current_scene.add_child(asteroid)
	asteroid.global_position = random_point()
	asteroid.add_to_group("asteroid")


func random_point():
	var half = box.shape.size / 2
	return box.global_position + Vector2(
		randf_range(-half.x, half.x),
		randf_range(-half.y, half.y)
	)
