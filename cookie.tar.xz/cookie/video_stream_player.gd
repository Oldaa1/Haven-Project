extends VideoStreamPlayer

var min_wait = 2.0
var max_wait = 5.0

var video = preload("res://output.ogv")

func _ready():
	randomize()
	loop()

func loop():
	while true:
		await get_tree().create_timer(randf_range(min_wait, max_wait)).timeout
		stream = video
		play()
