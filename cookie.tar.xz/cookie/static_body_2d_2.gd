extends StaticBody2D

@export var bounce_speed = 600

@onready var box = $CollisionShape2D


func _ready():
	var area = Area2D.new()
	var shape = CollisionShape2D.new()
	shape.shape = box.shape.duplicate()
	shape.shape.size += Vector2(4, 4)
	shape.position = box.position
	area.add_child(shape)
	add_child(area)
	area.body_entered.connect(on_body_entered)


func on_body_entered(body):
	if not body is CharacterBody2D:
		return

	var offset = to_local(body.global_position) - box.position
	var half = box.shape.size / 2
	var normal = Vector2.ZERO

	if abs(offset.y / half.y) > abs(offset.x / half.x):
		normal = Vector2(0, sign(offset.y))
	else:
		normal = Vector2(sign(offset.x), 0)

	if normal.x != 0:
		body.velocity.x = normal.x * bounce_speed
	else:
		body.velocity.y = normal.y * bounce_speed
