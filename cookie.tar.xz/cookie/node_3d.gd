extends Node2D

@export var asteroid_scene: PackedScene
@export var start_delay = 1.0
@export var min_delay = 0.25
@export var speed_up = 0.02
@export var max_asteroids = 15
@export var active = true

var delay = 0.0


func _ready():
	randomize()
	if "collision_layer" in self:
		set("collision_layer", 0)
		set("collision_mask", 0)
	if asteroid_scene == null:
		push_error(name + "res://asteroid_1.tscn")
		return
	delay = start_delay
	run()


func run():
	while true:
		await get_tree().create_timer(delay).timeout
		if active and get_tree().get_nodes_in_group("asteroid").size() < max_asteroids:
			spawn()
			delay = max(min_delay, delay - speed_up)


func spawn():
	var asteroid = asteroid_scene.instantiate()
	get_tree().current_scene.add_child(asteroid)
	asteroid.global_position = global_position
	asteroid.add_to_group("asteroid")
