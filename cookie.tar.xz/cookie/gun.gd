extends Node2D

@export var bullet_image: Texture2D
@export var bullet_speed = 800
@export var fire_delay = 0.1
@export var bullet_life = 1.5
@export var push_force = 300
@export_flags_2d_physics var collision_mask = 1

@onready var pivot = $pivo
@onready var muzzle = $konec

var direction = Vector2.RIGHT
var timer = 0.0
var bullets = []


func _ready():
	if bullet_image == null:
		bullet_image = load("res://projectile.png")


func _process(delta):
	var x = 0
	var y = 0
	if Input.is_physical_key_pressed(KEY_RIGHT):
		x += 1
	if Input.is_physical_key_pressed(KEY_LEFT):
		x -= 1
	if Input.is_physical_key_pressed(KEY_DOWN):
		y += 1
	if Input.is_physical_key_pressed(KEY_UP):
		y -= 1

	if x != 0 or y != 0:
		direction = Vector2(x, y).normalized()
		pivot.rotation = direction.angle()
		if direction.x < 0:
			pivot.scale.y = -1
		else:
			pivot.scale.y = 1

	timer -= delta
	if Input.is_action_pressed("shoot") and timer <= 0:
		shoot()
		timer = fire_delay

	queue_redraw()


func shoot():
	var bullet = {
		"pos": muzzle.global_position,
		"vel": direction * bullet_speed,
		"life": bullet_life,
		"hits": 0,
	}
	bullets.append(bullet)

	var player = get_parent()
	if "velocity" in player:
		player.velocity -= direction * push_force


func _physics_process(delta):
	var space = get_world_2d().direct_space_state

	for b in bullets.duplicate():
		b.life -= delta
		if b.life <= 0:
			bullets.erase(b)
			continue

		var next = b.pos + b.vel * delta
		var query = PhysicsRayQueryParameters2D.create(b.pos, next, collision_mask)
		if get_parent() is CollisionObject2D:
			query.exclude = [get_parent().get_rid()]
		var hit = space.intersect_ray(query)

		if hit.is_empty():
			b.pos = next
		else:
			b.hits += 1
			if b.hits >= 2:
				bullets.erase(b)
			else:
				b.vel = b.vel.bounce(hit.normal)
				b.pos = hit.position + hit.normal


func _draw():
	for b in bullets:
		draw_set_transform(to_local(b.pos), b.vel.angle() - global_rotation, Vector2.ONE)
		draw_texture(bullet_image, -bullet_image.get_size() / 2)
