extends RigidBody2D


func _ready():
	gravity_scale = 0
	linear_velocity = Vector2(randf_range(-100, 100), randf_range(50, 150))
	angular_velocity = randf_range(-2, 2)


func pop():
	get_tree().call_group("counter", "add_point")
	queue_free()
