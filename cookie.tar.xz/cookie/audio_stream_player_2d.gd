extends AudioStreamPlayer2D
## proc var nemuze bejt varlata
var min_wait = 60.0
var max_wait = 120.0
# cekani v sekundach minimum a max

var sounds = [
	preload("res://lobotomy.mp3"),
	preload("res://FYN.mp3"),
	preload("res://schizopost-laugh.mp3"),
]

func _ready():
	randomize()
	loop()

func loop():
	while true:
		await get_tree().create_timer(randf_range(min_wait, max_wait)).timeout
		stream = sounds.pick_random()
		play()
