extends Node2D

@export var turn_speed: float = -98.0
@export var bullet_scene: PackedScene

@onready var muzzle = $"CharacterBody2D/pistol ale/pivo/konec"

var aim_direction: Vector2 = Vector2.RIGHT
var target_angle: float
var is_rotating: bool = false

func _ready() -> void:
	target_angle = global_rotation
	aim_direction = Vector2.RIGHT.rotated(global_rotation).normalized()

func _process(delta: float) -> void:
	if is_rotating:
		global_rotation = rotate_toward(
			global_rotation,
			target_angle,
			turn_speed * delta
		)

		if abs(angle_difference(global_rotation, target_angle)) < 0.01:
			global_rotation = target_angle
			is_rotating = false
	else:
		var input_direction := Input.get_vector(
			"gun_left",
			"gun_right",
			"gun_up",
			"gun_down"
		)

		if input_direction != Vector2.ZERO:
			var new_angle := input_direction.angle()

			if abs(angle_difference(global_rotation, new_angle)) > 0.01:
				target_angle = new_angle
				aim_direction = input_direction.normalized()
				is_rotating = true

	if Input.is_action_just_pressed("jump_up"):
		shoot()

func shoot() -> void:
	if bullet_scene == null:
		return

	var bullet = bullet_scene.instantiate()
	get_tree().current_scene.add_child(bullet)
	bullet.global_position = muzzle.global_position
	bullet.global_rotation = aim_direction.angle()
